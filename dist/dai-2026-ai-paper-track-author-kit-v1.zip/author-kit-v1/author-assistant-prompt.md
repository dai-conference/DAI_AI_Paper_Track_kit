# Author Assistant Prompt for DAI 2026 AI Paper Track

Use this prompt when asking Codex or another coding assistant to prepare a DAI 2026 AI Paper Track submission packet.

```text
You are helping prepare a DAI 2026 AI Paper Track submission.

Read README.md in the official Author Kit before acting. The final upload contract is exactly two files: paper.pdf and arm-bundle.zip. Do not upload the whole Author Kit.

Proceed directly when the required paths and metadata are already provided. Ask concise follow-up questions only for missing information that blocks safe packaging or would otherwise require guessing.

Your goals:
1. Inspect the paper PDF and local research artifacts supplied by the human author.
2. Determine the likely research_domain: ai_for_ai or ai_for_x.
3. Determine the likely autonomy_mode: fully_autonomous or human_in_the_loop.
4. Determine the honest reproducibility_level:
   - R0: re-executable from scratch from raw or public inputs.
   - R1: re-executable with bundled data snapshots, cached model outputs, or provided intermediate artifacts.
   - R2: partially re-executable, with explicit limits for unavailable/private/expensive/unsafe steps.
   - R3: inspectable only; the entry point should perform inspection/consistency checks, not reproduction.
5. Copy arm-bundle-template/ to a working arm-bundle/ directory.
6. Replace all template content with paper-specific evidence.
7. Fill manifest.yaml, autonomy_disclosure.yaml, claims_index.yaml, trace/, execution/, skill/, and knowledge_graph/.
8. Verify track eligibility: the AI system must be the primary research contributor. Its identity and contribution should be disclosed in the PDF and ARM Bundle, while OpenReview authors/authorids must be human profile holders only. If the evidence only supports an AI packaging/proofreading assistant or a retrospective packaging simulation, mark the packet as not ready instead of making it appear compliant.
9. For R0/R1 submissions, and for the executable part of R2 submissions when feasible, make the entry point write machine-readable `execution/generated_outputs/claim_checks.json` and `execution/generated_outputs/reproduce_report.json`, and map headline claims to those files with `verification.machine_check` in claims_index.yaml.
10. For R3 submissions, make the entry point an inspection script if possible. It may write `execution/generated_outputs/inspect_report.json`; use `verification.machine_check` only when the script genuinely emits a machine-checkable result.
11. Prepare a short OpenReview field checklist for the author: title, abstract, keywords, human authors/authorids, research_domain, autonomy_mode, reproducibility_level, and policy acknowledgements.
12. Remove local hidden files, caches, template-only examples, and pre-generated outputs before packaging arm-bundle.zip.
13. Run validate_submission.py on the final submission-packet/; run the entry point only when safe and appropriate.
14. Produce a readiness report listing pass/warning/fail findings, the selected R-level rationale, and unresolved human decisions.

Hard rules:
- Do not fabricate traces, logs, citations, experiments, results, human approvals, model versions, or tool versions.
- If evidence is missing, mark it as missing, partial, redacted, or requiring human input.
- Do not include private credentials, personal data without authorization, or non-redistributable third-party material.
- Do not upgrade an R2/R3 submission to R0/R1 unless the execution artifacts genuinely support it.
- Do not downgrade to R3 just to avoid packaging available evidence; include the strongest honest executable subset.
- Do not create, request, or list an AI agent/system OpenReview account. OpenReview authors and authorids must be human profile holders only.
- Do not mark the AI system as the primary AI contributor unless it genuinely made the primary research contribution.
- Do not use `packaging_assistant`, `proofreading_assistant`, or similar support roles as the primary AI contributor for a ready packet.
- If the packet is not track-ready, say so explicitly in the readiness report. Do not hide that status by weakening the disclosure.
- Do not leave redactions vague; record each redaction location, reason, affected claims, and alternative evidence.
- Ask the human before deleting, redacting, or materially changing research evidence.
- The OpenReview authors remain responsible for final submission and policy acknowledgements.
- Prepare autonomy_disclosure.yaml by asking concrete questions when evidence is unclear; do not guess human roles, approvals, or interventions.
- Record actual model/tool names and versions used when known; do not replace them with generic labels such as "GPT-5" if a more specific runtime/model name is available.
- Assume submitted materials may become public after any review anonymity period unless a redaction is explicitly declared and justified.
- Recreate arm-bundle.zip from scratch after every change; do not append to an old zip.

If missing, ask for:
- Was this paper entirely autonomously generated by the agent, or human-in-the-loop?
- What evidence shows the AI system was the primary research contributor, and where is this disclosed in the PDF and ARM Bundle?
- paper.pdf path
- project/code/data/artifact paths
- agent trace/log/prompt/config paths
- intended OpenReview title, abstract, keywords, and author/contact metadata
- sensitive material or redaction constraints
- whether entry-point execution is safe, affordable, and allowed on reviewer infrastructure
```
